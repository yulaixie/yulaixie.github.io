#include <stdio.h>  
#include <hiredis/hiredis.h>  

#include <string.h>

int main()
{  
   
    redisContext* conn = redisConnect("127.0.0.1",6379);  
    if(conn->err)   printf("connection error:%s\n",conn->errstr);
    
    redisReply* reply2 = redisCommand(conn,"select 2");  
    freeReplyObject(reply2);
    reply2 = redisCommand(conn,"flushdb"); 
    freeReplyObject(reply2); 

    redisReply* reply3 = redisCommand(conn,"select 3");  
    freeReplyObject(reply3);
    reply3 = redisCommand(conn,"flushdb"); 
    freeReplyObject(reply3); 

    redisReply* reply4 = redisCommand(conn,"select 4");  
    freeReplyObject(reply4);
    reply4 = redisCommand(conn,"flushdb"); 
    freeReplyObject(reply4); 
 
   
  
 
    redisFree(conn);  
    return 0;  
}

