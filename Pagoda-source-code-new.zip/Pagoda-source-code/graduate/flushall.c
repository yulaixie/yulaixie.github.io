#include <stdio.h>  
#include <hiredis/hiredis.h>  

#include <string.h>

int main()
{  
   
    redisContext* conn = redisConnect("127.0.0.1",6379);  
    if(conn->err)   printf("connection error:%s\n",conn->errstr);
    
   
    redisCommand(conn,"flushall"); 


 
    redisFree(conn);  
    return 0;  
}

