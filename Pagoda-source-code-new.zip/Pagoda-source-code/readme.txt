#xxxxxx Intrusion Detection System

#### How to run it: 

Open redis service by running the following command:

`/redis-3.0.3/src/redis-server`

#####There are four steps to generating a rule base.

At `graduate` directory, run:

1.`./flushall `

2.`/jiance-redis/jiance <filename> -d 'g'`

3.`/jiance-redis/jiance <filename> -d 'p'`

4.`/jiance-redis/jiance <filename> -d 'b'`

The data will be imported into the redis database.

#####There are three steps to perform the detection step.

At `graduate` directory, run:

1.`./flushdb  `

2.`./redis <filename1> <filename2>`

3.`/jiance-redis/jiance <filename> -d 'j'`


