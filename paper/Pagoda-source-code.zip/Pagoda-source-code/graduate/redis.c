#include <stdio.h>  
#include <hiredis/hiredis.h>  

#include <string.h>

int main(int argc, char **argv)
{  

     FILE *fp; 
     FILE *fi,*fo;
     char key[100],value[100];
 
  
    redisContext* conn = redisConnect("127.0.0.1",6379);  
    if(conn->err)   printf("connection error:%s\n",conn->errstr);
    
    fi=fopen(argv[1],"r");
   
   while(fscanf(fi,"%s",&key)!=EOF)
   {    
	fscanf(fi,"%s",&value);
        if(strstr(value,"192."))  strcpy(value,"SOCKET");
        char s[20];
        sscanf(key,"%[^.]",s);

        redisReply* reply = redisCommand(conn,"select 2");  
    	freeReplyObject(reply);
   	reply = redisCommand(conn,"set %s %s",s,value);  
   	freeReplyObject(reply);
   }
   
   fclose(fi);

   fi=fopen(argv[2],"r");
   
   while(fscanf(fi,"%s",&key)!=EOF)
   {    
	fscanf(fi,"%s",&value);
         redisReply* reply = redisCommand(conn,"select 3");  
    	freeReplyObject(reply);
   	reply = redisCommand(conn,"sadd %s %s",value,key);  
   	freeReplyObject(reply);

        reply = redisCommand(conn,"select 4");  
    	freeReplyObject(reply);
   	reply = redisCommand(conn,"sadd %s %s",key,value);  
   	freeReplyObject(reply);
   }
   
   fclose(fi);
  
 
    redisFree(conn);  
    return 0;  
}

