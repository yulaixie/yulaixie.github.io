#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <getopt.h>
#include <assert.h>
#include <sys/time.h>
#include <utime.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <time.h>

#include <db.h>
#include "debug.h"

#include "twig.h"
#include "schema.h"
#include "wdb.h"


#include <linux/types.h>
#include <asm/types.h>

#include <hiredis/hiredis.h>  


static void dump_something(int ch);
static char * get_string(pnode_t pnum, const char * attr);
static char * get_newname(pnode_t pnum, const char * attr);
static char * get_newstring(int pnum);
char* version(char *);
char* comp(char *);
char* comp1(char *);
static void prune_guize(void);
static void guize(void);
static void bianma(void);
static void jiance(void);
static void test(void);
static int online_detect(char *);
static void newname(void);


static int j_len=0;
static int depi=0;
static int flag=0;
static int flag_lujing=0;
static int ii_intrusion=0;

struct node_pro{
	char * name;
	struct node_por *next;
};

struct node_pro *list_father;//the node have already visited
struct node_pro *list_head_record;//the head of chuan

struct node_pos{
	int len;
	double possible;
	struct node_pos *next;
};
struct node_pos *list_pos;

redisContext* conn;

static void usage(char *name)
{
   fprintf(stderr,
           "Usage: %s [options] [<path>]\n"
           "   -a             dump all tables\n"
           "   -d xyz         dump selected tables in order given\n"
           "   -h             print usage\n"
       "Tables:\n"
           
           "   z                chakanguize\n"
           "   g               shengchengguize\n"
           "If no path is specified \".\" is used.\n"
           "If no tables are specified, all are dumped.\n",
           name );
}


int main(int argc, char *argv[])
{
   const  char          *path = ".";
   const  char          *dumps = "TNaeipn><dmg";
   int                   ch, i;
   struct timeval start,end;
   float timeopen;
   

   conn = redisConnect((char *)"127.0.0.1",6379); 
    if(conn->err)   printf("connection error:%s\n",conn->errstr);  
   //
   // Parse options
   //
   while ( -1 != (ch = getopt(argc, argv, "ad:h")) ) {
      switch ( ch ) {
         case 'a':
        dumps = "TNaeipn><dz";
        break;
         case 'd':
        dumps = optarg;
        break;
         case 'h':
         default:
            usage(argv[0]);
            return 1;
      }
   }

   // extra params -> print usage
   if ( optind == argc - 1 ) {
      path = argv[optind];
   }
   else {
      usage(argv[0]);
      return 1;
   }

   //
   // Initialize all 'databases' (database & log)
   //
   gettimeofday(&start,NULL);
   if (wdb_startup(path, WDB_O_RDWR| WDB_O_CREAT) < 0) {
      fprintf(stderr, "wdb_dump: %s: %s\n", path, strerror(errno));
      exit(1);
   }
   gettimeofday(&end,NULL);
   timeopen = 1000000*(end.tv_sec-start.tv_sec)+end.tv_usec-start.tv_usec;
  /// printf("======Open DB Time: %f microseconds , %f s ======\n",timeopen,timeopen/1000000);
   //
   // Dump everything
   //
   for (i=0; dumps[i]; i++) {
      dump_something(dumps[i]);
   }

   //
   // Shut everything down (database & log)
   //
   wdb_shutdown();
   
    redisFree(conn);  

   exit(0);
}

static void dump_something(int ch) {
   switch (ch) {
    
    case 'g': guize();break;
    case 'b': bianma();break;
    case 'p': prune_guize();break;
    case 'j': jiance();break;
    case 't': test();break;
    case 'i': insert();break;

    default:
     fprintf(stderr, "Unknown dump target %c\n", ch);
     exit(1);
   }
}


void insert(){          //xingcheng  childdb and  newnamedb
   DBC                  *childc = NULL;
   DBC                  *newnamec = NULL;
   DBT                   dbt_child;
   DBT                   dbt_parent;
   DBT                   dbt_pnode;
   DBT                   dbt_name; 
   provdb_key            child;
   provdb_key            parent;
   char                 *name;
   pnode_t               pnum;
   int                   ret,ret1;
   char *  pname;
   char *  cname;
   FILE *fp; 
   FILE *fi,*fo;
   char key[100],value[100];


   memset(&dbt_child, 0, sizeof(dbt_child));
   memset(&dbt_parent , 0, sizeof(dbt_parent));

   fi=fopen("/test/deamon/2.txt","r");
   
   while(fscanf(fi,"%s",&key)!=EOF)
   {    
	fscanf(fi,"%s",&value);
        char s1[20],s2[20];
        sscanf(key,"%[^.]",s1);
        sscanf(key,"%*[^.]%*c%s",s2); 
        child.pnum=atoi(s1);
 	child.version=atoi(s2);

	sscanf(value,"%[^.]",s1);
        sscanf(value,"%*[^.]%*c%s",s2); 
        parent.pnum=atoi(s1);
 	parent.version=atoi(s2);

	dbt_child.data = &child;
        dbt_child.size = sizeof(child);
        dbt_parent.data = &parent;
        dbt_parent.size = sizeof(parent);
        
      	ret1 = g_childdb->db->put(g_childdb->db,NULL,&dbt_parent,&dbt_child,g_childdb->put_flags);
      	if ( ret1 == DB_KEYEXIST ) {
      	#ifdef DEBUG
            	fprintf( stderr,
                	"name index: key %*s for pnode %llu already recorded\n",
                     length, val->pdb_data, key->pnum );
      	#endif /* DEBUG */
      	 } else {
           	 wdb_check_err(ret1);
      	}

    
   }
  
   fclose(fi);


   memset(&dbt_name , 0, sizeof(dbt_name));
   memset(&dbt_pnode, 0, sizeof(dbt_pnode));

   fi=fopen("/test/deamon/1.txt","r");
   
   while(fscanf(fi,"%s",&key)!=EOF)
   {   
	fscanf(fi,"%s",&value);
	char s3[20];
        sscanf(key,"%[^.]",s3);
        pnum=atoi(s3); 
	dbt_pnode.data = &pnum;
        dbt_pnode.size = sizeof(pnum);
        
	if(strstr(value,"192."))  strcpy(value,"SOCKET");
        dbt_name.data = value;
        dbt_name.size = strlen(value)+1;

	ret1 = g_newnamedb->db->put(g_newnamedb->db,NULL,&dbt_pnode,&dbt_name,g_newnamedb->put_flags);
      	if ( ret1 == DB_KEYEXIST ) {
      	#ifdef DEBUG
            	fprintf( stderr,
                	"name index: key %*s for pnode %llu already recorded\n",
                     length, val->pdb_data, key->pnum );
      	#endif /* DEBUG */
      	 } else {
           	 wdb_check_err(ret1);
      	}
   }
   fclose(fi);
 	
}



void newname(void)
{
   DBC                  *namec = NULL;
   DBT                   dbt_pnode;
   DBT                   dbt_name;
   char                 *name;
   pnode_t               pnum;
   int                   ret,ret1;
   int i=0;
  
  
   memset(&dbt_name , 0, sizeof(dbt_name));
   memset(&dbt_pnode, 0, sizeof(dbt_pnode));
   
   ret=g_namedb->db->cursor(g_namedb->db,NULL,&namec,0);
   wdb_check_err(ret);

   while(0==(ret = namec->c_get(namec,&dbt_name,&dbt_pnode,DB_NEXT)) )  {
      
   
      ret1 = g_newnamedb->db->put(g_newnamedb->db,NULL,&dbt_pnode,&dbt_name,g_newnamedb->put_flags);
      if ( ret1 == DB_KEYEXIST ) {
      #ifdef DEBUG
            fprintf( stderr,
                "name index: key %*s for pnode %llu already recorded\n",
                     length, val->pdb_data, key->pnum );
      #endif /* DEBUG */
       } else {
            wdb_check_err(ret1);
      }

     free(name),name=NULL;

   }

   if ( DB_NOTFOUND != ret ) {
      wdb_check_err(ret);
   }

  
}

static char * get_newstring(int pnum)    //return name
{
   
   char                      *data = NULL;
   
   char pnode[10] ;
 //  printf("pnum:%d\n",pnum);
  // redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
  // if(conn->err)   printf("connection error:%s\n",conn->errstr); 
   redisReply* reply = redisCommand(conn,"select 2");  
   freeReplyObject(reply);
   sprintf(pnode,"%d",pnum);
   
   //printf("%s\n",pnode);
   reply = redisCommand(conn,"get %s",pnode); 
   if (reply->type == REDIS_REPLY_STRING)  
   {  
        int len =strlen(reply->str);
	data=malloc(len+1);
        memcpy(data,reply->str,len);
        data[len]=0;
   }
   freeReplyObject(reply);
   //redisFree(conn);
  
   return data;
    
  

}




void get_head_list(void){

   char                 *pname;
   int i; 
   

   list_father=(struct node_pro *)malloc(sizeof(struct node_pro));
   list_father->next=NULL;
   list_head_record=(struct node_pro *)malloc( sizeof(struct node_pro));
   list_head_record->next=NULL;


    
   //redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
   //if(conn->err)   printf("connection error:%s\n",conn->errstr); 
   redisReply* reply = redisCommand(conn,"select 3");  
   freeReplyObject(reply); 
   redisReply* r = redisCommand(conn,"keys *");   
   for (i = 0; i < r->elements; ++i) {  
         redisReply* childReply = r->element[i];  
	 int len =strlen(childReply->str);
	 pname=malloc(len+1);
         memcpy(pname,childReply->str,len);
         pname[len]=0;
         get_head_record(pname);

         freeReplyObject(childReply);

         free(pname), pname = NULL;
    }    
   // freeReplyObject(r);	
  //  redisFree(conn);  

	
}	


int get_head_record(char* jchild)
{
  
   char *jparent;
   int j;

   
   struct node_pro *p;
   struct node_pro *q;

   struct node_pro *p1,*q1;

  // memset(&dbt_child, 0, sizeof(dbt_child));
  // memset(&dbt_parent , 0, sizeof(dbt_parent));



   if(!found_list_father(list_father,jchild))// not visited ,add to the list_father list,else visited alyet return ;
   {
        //printf("father %llu %u\n",jchild->pnum,jchild->version);
	q1=(struct node_pro *)malloc(sizeof(struct node_pro));
        int len =strlen(jchild);
	q1->name=malloc(len+1);
	memcpy(q1->name,jchild,len);
        q1->name[len]=0;
        q1->next=NULL;

	p1=list_father;
	while(p1->next)
		p1=p1->next;
	
	p1->next=q1;
   }
   else
   {
	return 0;
   }
   

  // redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
  // if(conn->err)   printf("connection error:%s\n",conn->errstr); 
   redisReply* reply = redisCommand(conn,"select 4");  
   freeReplyObject(reply); 

   reply = redisCommand(conn,"smembers %s",jchild); 
   if(reply->elements==0) {
     	q=(struct node_pro *)malloc(sizeof(struct node_pro));
	int len =strlen(jchild);
	q->name=malloc(len+1);
	memcpy(q->name,jchild,len);
        q->name[len]=0;
	q->next=NULL;
	//q1->name=cname;

	p=list_head_record;
	while(p->next)
		p=p->next;
	
	p->next=q;
	
	return 0;
   }
   for(j=0;j<reply->elements;++j){
         if (reply->element[j]->type == REDIS_REPLY_STRING)  
         {       //printf(" %s  ",reply->element[j]->str); 
		int len =strlen(reply->element[j]->str);
		jparent=malloc(len+1);
		memcpy(jparent,reply->element[j]->str,len);
        	jparent[len]=0;
		get_head_record(jparent);

		free(jparent),jparent=NULL;
	 }
   }
   
   freeReplyObject(reply);	
  // redisFree(conn);  

 
   return 0;
}


int found_list_father(struct node_pro * head,char* jchild)
{
	int flag=0;
	struct node_pro *p=head->next;
        
	while(p)
	{
                        //printf("%llu %u  %llu  %u\n",p->name.pnum,p->name.version,jchild->pnum,jchild->version);
			if(strcmp(p->name,jchild)==0)
			{
				flag=1;
				return flag;
			}
			p=p->next;
	}

	return flag;
} 


void test(void)
{
  
   char *  pname;
   char *  cname;
   int  parent_pnum=0,child_pnum=0;
   int i,j;  


 
   // Iterate over the main database

   //redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
    // if(conn->err)   printf("connection error:%s\n",conn->errstr);  
   redisReply* reply = redisCommand(conn,"select 3");  
   freeReplyObject(reply);

   redisReply* r = redisCommand(conn,"keys *");  

   for (i = 0; i < r->elements; ++i) { 

         redisReply* childReply = r->element[i];  

         if (childReply->type == REDIS_REPLY_STRING)  
	 {  
	     parent_pnum=f_pnum(childReply->str);  
	 }

	 pname = get_newstring(parent_pnum);
	 if(pname==NULL) continue;

	 redisReply* replys = redisCommand(conn,"smembers %s",childReply->str);  
         for(j=0;j<replys->elements;++j){

             if (replys->element[j]->type == REDIS_REPLY_STRING) 
		 child_pnum=f_pnum(replys->element[j]->str);    
	     //printf("%s--\n",replys->element[j]->str);
 	     cname = get_newstring(child_pnum);  
             if(cname==NULL) continue;
	    
             if(strstr(pname,"mount")||strstr(pname,"PIPE")||strstr(pname,"tmp")||strstr(pname,"/pulse-shm")||strstr(pname,"lasagna")||strstr(pname,".cache")||strstr(pname,"./configure")||strstr(pname,"./Configure")||strstr(cname,"mount")||strstr(cname,"PIPE")||strstr(cname,"tmp")||strstr(cname,"/pulse-shm")||strstr(cname,"lasagna")||strstr(cname,".cache")||strstr(cname,"./configure")||strstr(cname,"./Configure")||strstr(cname,"Cache")||strstr(cname,"cache")||strstr(cname,"CACHE")||strstr(cname,"pass")||strstr(cname,"default")||strstr(pname,"Cache")||strstr(pname,"cache")||strstr(pname,"CACHE")||strstr(pname,"pass")||strstr(pname,"default")||strstr(pname,"./")||strstr(cname,"./")||strstr(pname,"conf.")||strstr(cname,"conf.")||strstr(pname,".swp")||strstr(cname,".swp")||strstr(pname,".so")||strstr(cname,".so")||strstr(pname,".sh")||strstr(cname,".sh")
||((pname[0]=='/')&&(pname[1]>='0'&&pname[1]<='9')&&(pname[2]>='0'&&pname[2]<='9')&&(pname[3]=='/'))  
||((pname[0]=='/')&&(pname[1]>='0'&&pname[1]<='9')&&(pname[2]>='0'&&pname[2]<='9')&&(pname[3]>='0'&&pname[3]<='9')&&(pname[4]=='/'))
||((pname[0]=='/')&&(pname[1]>='0'&&pname[1]<='9')&&(pname[2]>='0'&&pname[2]<='9')&&(pname[3]>='0'&&pname[3]<='9')&&(pname[4]>='0'&&pname[4]<='9')&&(pname[5]=='/'))
||((pname[0]=='/')&&(pname[1]>='0'&&pname[1]<='9')&&(pname[2]>='0'&&pname[2]<='9')&&(pname[3]>='0'&&pname[3]<='9')&&(pname[4]>='0'&&pname[4]<='9')&&(pname[5]>='0'&&pname[5]<='9')&&(pname[6]=='/'))
||((cname[0]=='/')&&(cname[1]>='0'&&cname[1]<='9')&&(cname[2]>='0'&&cname[2]<='9')&&(cname[3]=='/'))
||((cname[0]=='/')&&(cname[1]>='0'&&cname[1]<='9')&&(cname[2]>='0'&&cname[2]<='9')&&(cname[3]>='0'&&cname[3]<='9')&&(cname[4]=='/'))
||((cname[0]=='/')&&(cname[1]>='0'&&cname[1]<='9')&&(cname[2]>='0'&&cname[2]<='9')&&(cname[3]>='0'&&cname[3]<='9')&&(cname[4]>='0'&&cname[4]<='9')&&(cname[5]=='/'))
||((cname[0]=='/')&&(cname[1]>='0'&&cname[1]<='9')&&(cname[2]>='0'&&cname[2]<='9')&&(cname[3]>='0'&&cname[3]<='9')&&(cname[4]>='0'&&cname[4]<='9')&&(cname[5]>='0'&&cname[5]<='9')&&(cname[6]=='/')) )
             {
                   //printf("shan\n%s %s\n",childReply->str,replys->element[j]->str);

                   
                   redisReply* replydb = redisCommand(conn,"select 4");  
  	 	   freeReplyObject(replydb);                    
                  redisReply* replydel_p = redisCommand(conn,"srem %s %s",replys->element[j]->str,childReply->str);
  		  freeReplyObject(replydel_p); 

		  replydb = redisCommand(conn,"select 3");  
  	 	   freeReplyObject(replydb);
   		  redisReply* replydel_c = redisCommand(conn,"srem %s %s",childReply->str,replys->element[j]->str); 
                  freeReplyObject(replydel_c); 

             }
      
         } 
	
         free(cname), cname = NULL;
         free(pname), pname = NULL;
          freeReplyObject(replys);
    }  
    freeReplyObject(r);
    //redisFree(conn); 
   
}


find(char * s1 ,char * s2)
{
  
   //char                        *c;
   int                           ret,r=1,j;
   char * new1=NULL;
   char * new2=NULL;
   char* new11=NULL;
   char* new22=NULL;
	
	int flag,flag1;
	char a[500][100];
	
 if(strstr(s1,"mount")||strstr(s1,"PIPE")||strstr(s1,"tmp")||strstr(s1,"/pulse-shm")||strstr(s1,"lasagna")||strstr(s1,".cache")||strstr(s1,"./configure")||strstr(s1,"./Configure")||strstr(s2,"mount")||strstr(s2,"PIPE")||strstr(s2,"tmp")||strstr(s2,"/pulse-shm")||strstr(s2,"lasagna")||strstr(s2,".cache")||strstr(s2,"./configure")||strstr(s2,"./Configure")||strstr(s2,"Cache")||strstr(s2,"cache")||strstr(s2,"CACHE")||strstr(s2,"pass")||strstr(s2,"default")||strstr(s1,"Cache")||strstr(s1,"cache")||strstr(s1,"CACHE")||strstr(s1,"pass")||strstr(s1,"default")||strstr(s1,"./")||strstr(s2,"./")||strstr(s1,"conf.")||strstr(s2,"conf.")||strstr(s1,".swp")||strstr(s2,".swp")||strstr(s1,".so")||strstr(s2,".so")||strstr(s1,".sh")||strstr(s2,".sh")
||((s1[0]=='/')&&(s1[1]>='0'&&s1[1]<='9')&&(s1[2]>='0'&&s1[2]<='9')&&(s1[3]=='/'))  
||((s1[0]=='/')&&(s1[1]>='0'&&s1[1]<='9')&&(s1[2]>='0'&&s1[2]<='9')&&(s1[3]>='0'&&s1[3]<='9')&&(s1[4]=='/'))
||((s1[0]=='/')&&(s1[1]>='0'&&s1[1]<='9')&&(s1[2]>='0'&&s1[2]<='9')&&(s1[3]>='0'&&s1[3]<='9')&&(s1[4]>='0'&&s1[4]<='9')&&(s1[5]=='/'))
||((s1[0]=='/')&&(s1[1]>='0'&&s1[1]<='9')&&(s1[2]>='0'&&s1[2]<='9')&&(s1[3]>='0'&&s1[3]<='9')&&(s1[4]>='0'&&s1[4]<='9')&&(s1[5]>='0'&&s1[5]<='9')&&(s1[6]=='/'))
||((s2[0]=='/')&&(s2[1]>='0'&&s2[1]<='9')&&(s2[2]>='0'&&s2[2]<='9')&&(s2[3]=='/'))
||((s2[0]=='/')&&(s2[1]>='0'&&s2[1]<='9')&&(s2[2]>='0'&&s2[2]<='9')&&(s2[3]>='0'&&s2[3]<='9')&&(s2[4]=='/'))
||((s2[0]=='/')&&(s2[1]>='0'&&s2[1]<='9')&&(s2[2]>='0'&&s2[2]<='9')&&(s2[3]>='0'&&s2[3]<='9')&&(s2[4]>='0'&&s2[4]<='9')&&(s2[5]=='/'))
||((s2[0]=='/')&&(s2[1]>='0'&&s2[1]<='9')&&(s2[2]>='0'&&s2[2]<='9')&&(s2[3]>='0'&&s2[3]<='9')&&(s2[4]>='0'&&s2[4]<='9')&&(s2[5]>='0'&&s2[5]<='9')&&(s2[6]=='/')) )
{  
    r=0;return r;
}

         new1=strstr(s1,"/home/apps/apache");
         new2=strstr(s2,"/home/apps/apache");
      if(new1!=NULL)
       {
      
        new11=comp(s1);
        new1=version(new11);
        s1=new1;
       }
       if(new2!=NULL)
       {
     
        new22=comp(s2);
        new2=version(new22);
        s2=new2;
       }
 

	//memset(&key,0,sizeof(key));
	//memset(&data,0,sizeof(data)); 
	   
	flag=0;
	//key.data=s1;
	//key.size=strlen(s1)+1; 
        
        
    //	redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
   	//if(conn->err)   printf("connection error:%s\n",conn->errstr);  
  	redisReply* reply = redisCommand(conn,"select 1");  
  	freeReplyObject(reply);
 	
	reply = redisCommand(conn,"get %s",s1);
	if(reply->type == REDIS_REPLY_STRING) 
  	{
		///printf("%s->%s\n",(char *)key.data,(char *)data.data);	
		strcpy(a[0],reply->str);
		flag=1;
		
	}
  	freeReplyObject(reply);

       	if(flag==0)	
        {
		
		jiequ(s1,a[0],a[1]);
		//key.data=a[0];
		//key.size=strlen(a[0])+1;
		reply = redisCommand(conn,"get %s",a[0]);
		if((reply->type == REDIS_REPLY_STRING)&&strcmp(a[0],"")!=0) 
  	  	{
			///printf("%s->%s\n",(char *)key.data,(char *)data.data);	
			strcpy(a[0],reply->str);
			strcat(a[0],a[1]);
			flag=1;
		}
		freeReplyObject(reply);
		///else  printf("shuru errror:%s\n",s1);
	}

	//key.data=s2;
	//key.size=strlen(s2)+1;
        flag1=0;
	//if(strstr(s2,"192.")) {printf("asds");strcpy(s2,"SOCKET");}
	//printf("s2:%s\n",s2);

	reply = redisCommand(conn,"get %s",s2);
	if(reply->type == REDIS_REPLY_STRING) 
  	{
		//printf("%s->%s\n",(char *)key.data,(char *)data.data);	
		strcpy(a[1],reply->str);
		flag1=1;
		
	}
  	freeReplyObject(reply);

       	if(flag1==0)	
        {
		
		jiequ(s2,a[0],a[2]);
		//key.data=a[0];
		//key.size=strlen(a[0])+1;
		reply = redisCommand(conn,"get %s",a[0]);
		if((reply->type == REDIS_REPLY_STRING)&&strcmp(a[0],"")!=0) 
  	  	{
			///printf("%s->%s\n",(char *)key.data,(char *)data.data);	
			strcpy(a[1],reply->str);
			strcat(a[1],a[2]);
			flag1=1;
		}
		freeReplyObject(reply);
		//else  printf("shuru errror:%s\n",s2);
	}

	if(flag==1&&flag1==1)
	{
		redisReply* replysel = redisCommand(conn,"select 0");  
  			freeReplyObject(replysel);
		reply = redisCommand(conn,"smembers %s",a[0]);
		for(j=0;j<reply->elements;++j)
                   if (reply->element[j]->type == REDIS_REPLY_STRING && strcmp(reply->element[j]->str,a[1])==0)  
                      r=0;
		freeReplyObject(reply);
	
	}
      //  redisFree(conn); 
   if(new1!=NULL)
   {
   free(new1);
   new1=NULL;
   s1=NULL;
   }
   if(new11!=NULL)
   {
   free(new11);
   new11=NULL;
   }
   if(new2!=NULL)
   {
    free(new2);
    new2=NULL;
    s2=NULL;
   }
   if(new22!=NULL)
   {
    free(new22);
    new22=NULL;
   }
   return r;

}

void list_pos_add(int len,double possible){
	struct node_pos *p=NULL;
	struct node_pos *q=NULL;
	//if(len>=3) {
		p=(struct node_pos *)malloc(sizeof(struct node_pos));
		p->next=NULL;
		p->len=len;
		p->possible=possible;

		
		list_pos->len+=len;
        	//printf("%lf\n",possible);
		
		q=list_pos->next;
       	 	if(!q)  list_pos->next=p;
        	else
		{
			list_pos->next=p;
                	p->next=q;
		}
	//}
	
}


int online_detect(char* jparent)
{
//printf("Insert: %llu->%llu\n",pname,cname);
  
  
   int r=0;
   int aa=0;
   int x=0;
   char *  pname=NULL;
   char *  cname=NULL;
   char *jchild;
   int j;
   int flag_len;

   double possible=0.0;
   int  parent_pnum=0,child_pnum=0;

  
   if(flag_lujing==1) return 0;
  // redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
 //      if(conn->err)   printf("connection error:%s\n",conn->errstr);  
   redisReply* reply = redisCommand(conn,"select 3");  
   freeReplyObject(reply);
   //printf("%s\n",jparent);

   reply = redisCommand(conn,"smembers %s",jparent); 

   //printf("childcount:%d\n",reply->elements);
   if(reply->elements==0) {
	 if(j_len<=0) return 0;
         //printf("j_len %d depi %d\n",j_len,depi);
	 possible=(double)depi/j_len;
	 if(possible>0.7&& j_len>=2){ flag_lujing=1; return 0;}
	 list_pos_add(j_len,possible);
         flag+=1;
        // printf("%d   %lf flag\n",j_len,possible,flag);
         return;
   }
  // printf(" %s  ",reply->element[0]->str);
   for(j=0;j<reply->elements;++j){
         if (reply->element[j]->type == REDIS_REPLY_STRING)  
         {     
 		//printf("childname:%s\n",reply->element[j]->str);
		//j_len++; 
flag_len=0;
		int len =strlen(reply->element[j]->str);
		jchild=malloc(len+1);
		memcpy(jchild,reply->element[j]->str,len);
        	jchild[len]=0;
//printf("childname:%s\n",reply->element[j]->str);
		parent_pnum=f_pnum(jparent);  
                
		pname = get_newstring(parent_pnum);
///printf("childname:%s\n",reply->element[j]->str);                
		child_pnum=f_pnum(jchild);  
		cname = get_newstring(child_pnum);
 ///               printf("%s %s\n",pname,cname);
    	    	if(pname==NULL||cname==NULL) 
       		{
           		 r=0;
         		 
    		 }

     		 else
      		  {       r= find(pname,cname);//pipeishifoucunzai
			//printf("pname is %s,cname is %s. r=%d\n",pname,cname,r);
			  j_len++;flag_len=1;
		  }
                
    		 aa=depi;
    		 if(r)   
    		 {
     		     // printf("when r!=0,pname is %s,cname is %s.\n",pname,cname);
      		      free(pname),pname=NULL;
       		      free(cname),cname=NULL;
       		      depi+=1;
	   
    		 }
    		 else   {depi+=0;}
               //  printf("%s\n",jchild);
   		 x=j_len;
//printf("childname:%s\n",reply->element[j]->str);
 		
   		 online_detect(jchild);
    		 depi=aa;
    		 if(flag_len==1)j_len=x-1; 
		 else j_len=x;
		 
		 
                 //free(pname),pname=NULL;
       		 //free(cname),cname=NULL;
		 free(jchild),jchild=NULL;
		 
		
	  }
   }
   freeReplyObject(reply);
//   redisFree(conn);  
   return 0;
}



void jiance(void)
{
 
   char *            child;
   char msg[100];
   int ii_detect=0;
   FILE *file_intrusion;
   
   double possibleall=0.0;
   
   struct node_pro *p=NULL;
   struct node_pos *q=NULL;

   struct timeval start_read,end_read;
	float timeuse_read;
   
 //  newname();


   //test();
  
   get_head_list();
   ///printf("test\n");
   //compress_test();
  
 
   gettimeofday(&start_read,NULL);   


   // Open a cursor
     gettimeofday(&start_read,NULL);   
   
   list_pos=(struct node_pos *)malloc(sizeof(struct node_pos));
   list_pos->next=NULL;
   list_pos->len=0;//the head of this list node,the len attr is the length of the list;
   list_pos->possible=0.0;

   p=list_head_record->next;
   while(p){
       if(flag_lujing==1) break ;
      //child.pnum=p->name.pnum;
      //child.version=p->name.version;
      //int len =strlen(p->name);
      //child=malloc(len+1);
      //memcpy(child,p->name,len);
      //q->name[len]=0;
    //  printf("toujiedian:%s \n",p->name);
      online_detect(p->name);
      j_len=0;
      depi=0;
      p=p->next; 
 
   }

   if(flag_lujing==1)  ii_detect=1;
   else{
    q=list_pos->next;
    while(q){
     //printf("%d,%lf\n",q->len,q->possible);
     double weigth=(double)(q->len)/(double)(list_pos->len);
     possibleall+=q->possible*weigth;
     q=q->next;
    }
   }
   if(possibleall>=0.5) ii_detect=1;
   // printf("possibleall: %lf\n",possibleall);

    printf("%d\n",ii_detect);
  

   gettimeofday(&end_read,NULL);
   timeuse_read=1000000*(end_read.tv_sec-start_read.tv_sec)+end_read.tv_usec-start_read.tv_usec;

   
   ///printf("%d\n%d\n%d\n%f\n",ii_detect,ii_intrusion,flag,timeuse_read);
  
   //sprintf(msg,"%d\n%d\n%d\n%f\n",ii_detect,ii_intrusion,flag,timeuse_read);
   sprintf(msg,"%f\n",timeuse_read);
   file_intrusion=fopen("/test/db/intrusion-time.txt","a+");
   if(file_intrusion==NULL)
      printf("get file error.\n");

   fwrite(msg,sizeof(char),strlen(msg),file_intrusion);
   fclose(file_intrusion);
  


}




void bianma(void)
{
	
	DBT key,data,key1,data1,key2,data2;
	int ret,ret1;
	int i,k1=0,k2,k3,j=0,l,flag;
	char a[50000][100],b[10000][100],c[9000][100],c1[9000][100];
	char m[100],s[5000][100];
	DBC *cur=NULL;
	int count=0;
	memset(&key,0,sizeof(DBT));
	memset(&data,0,sizeof(DBT));  
	
	ret=g_guizenewdb->db->cursor(g_guizenewdb->db,NULL,&cur,0);
	wdb_check_err(ret);
 
	while((ret=cur->c_get(cur,&key,&data,DB_NEXT))==0) 
	{
		for(i=0;i<k1;i++)
		{
			
			strcpy(s[0],key.data);
			jiequ(key.data,s[0],s[1]);
			if(strcmp(s[0],a[i])==0)	
			{
				j++;
				sprintf(b[j],"%d",i+1);
				strcat(b[j],s[1]);
				break;
			}
		}
		if(i==k1)                                    
		{
			jiequ(key.data,s[0],s[1]);
			j++;
			if(strcmp(s[0],"")==0)  strcat(b[j],s[1]); 
			else
			{sprintf(b[j],"%d",i+1);
			strcat(b[j],s[1]);
			strcpy(a[k1],s[0]);  
			 k1++;}
			
		}
		for(i=0;i<k1;i++)
		{
			strcpy(s[0],data.data);
			jiequ(data.data,s[0],s[1]);
			if(strcmp(s[0],a[i])==0)
			{
				j++;
				sprintf(b[j],"%d",i+1);
				strcat(b[j],s[1]);	
				break;
			}
		}
		if(i==k1)   
		{ 
			strcpy(s[0],data.data);
			jiequ(data.data,s[0],s[1]);
			j++;
			if(strcmp(s[0],"")==0)  { strcat(b[j],s[1]); }
			else
			{sprintf(b[j],"%d",i+1);
			strcat(b[j],s[1]);
			strcpy(a[k1],s[0]);
			k1++;}
			
		}
                
	}

	strcpy(c[1],b[1]);
	strcpy(c1[1],b[1]);
	k2=1;
	printf("%d  %s...\n",k2,c1[k2]);
	for(i=2;i<=j;i++)  
	{       flag=0;
		for(l=1;l<=k2;l++)
		{
			if(strcmp(b[i],c[l])==0)
			{  
				
				flag=1; 
				jiequ(b[i],s[0],s[1]);
				if(strcmp(s[0],"")!=0)
				{k3=atoi(s[0]);  
				strcpy(c1[l],a[k3-1]);
				strcat(c1[l],s[1]);}
				else strcpy(c1[l],s[1]);
				break;
			}
		}
		if(flag==0)
		{ 
			k2++;  
			strcpy(c[k2],b[i]);   
			jiequ(b[i],c1[k2],s[1]);
			if(strcmp(c1[k2],"")!=0)  
			{k3=atoi(c1[k2]);
			strcpy(c1[k2],a[k3-1]);}
		}
	} 
	//printf("%d.....%d\n",k2,j);
        strcpy(s[1],c1[1]);
	k3=1;
	for(i=2;i<=k2;i++)     //s[] baocun bianma
	{       flag=0;
		for(l=1;l<=k3;l++)
		{
			if(strcmp(c1[i],s[l])==0)
			{  
				flag=1;   
				break;
			}
		}
		if(flag==0)
		{ 
			k3++;  
			strcpy(s[k3],c1[i]);   
		}
	} 
	memset(&key1,0,sizeof(key1));
	memset(&data1,0,sizeof(data1));
	for(i=1;i<=k3;i++)
	{
		sprintf(m,"%d",i); 
		data1.data=(char *)malloc(sizeof(char)*strlen(m));
		strcpy(data1.data,m);
		data1.size=strlen(m)+1;;
  		key1.data=s[i];
		key1.size=strlen(s[i])+1;
                ret1 = g_bianmadb->db->put(g_bianmadb->db, NULL,
                           &key1, &data1,
                           g_bianmadb->put_flags);

                if ( ret1 == DB_KEYEXIST ) {
                  #ifdef DEBUG
                      //printf("ffbd\n");
                      fprintf( stderr,
                          "name index: key %*s for pnode %llu already recorded\n",
                           length, val->pdb_data, key->pnum );
                                #endif /* DEBUG */
                } else {
                         wdb_check_err(ret1);
                      }  

		redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
                if(conn->err)   printf("connection error:%s\n",conn->errstr);  
   		redisReply* reply = redisCommand(conn,"select 1");  
    		freeReplyObject(reply);
    		reply = redisCommand(conn,"set %s %s",s[i],m); 
    		//redisCommand(conn,"sadd 1.0 %s",argv[2]); 
    		freeReplyObject(reply); 
		redisFree(conn);  

      	      
	}
	if ( DB_NOTFOUND != ret ) {
           wdb_check_err(ret);
       }		
	//printf("%d.....%d\n",k2,j);
	


	memset(&key,0,sizeof(DBT));
	memset(&data,0,sizeof(DBT));
	memset(&key2,0,sizeof(DBT));
	memset(&data2,0,sizeof(DBT));

 	ret=g_guizenewdb->db->cursor(g_guizenewdb->db,NULL,&cur,0);
	wdb_check_err(ret);

	while((ret=cur->c_get(cur,&key,&data,DB_NEXT))==0)           
	{       j++;
		flag=0;
		for(i=1;i<=k3;i++)
		{       
			
			if(strcmp(key.data,s[i])==0)
			{
				sprintf(m,"%d",i); 
				flag=1;
				strcpy(a[3],m);
				break;
			}
			
		}
		for(i=1;i<=k3;i++)	
		{	
			if(flag==1)  break;
			jiequ(key.data,a[0],a[1]);
			if(strcmp(a[0],s[i])==0)  
			{
				sprintf(m,"%d",i); 	
				strcpy(a[3],m);
				strcat(a[3],a[1]);
				break;
			}
		}
		flag=0;
		for(i=1;i<=k3;i++)
		{	
			if(strcmp(data.data,s[i])==0)
			{
				sprintf(m,"%d",i); 
				strcpy(a[4],m);
				flag=1;
				break;
			}
		}
		for(i=1;i<=k3;i++)	
		{
			if(flag==1)  break;
			jiequ(data.data,a[0],a[1]);
			if(strcmp(a[0],s[i])==0)  
			{	
				sprintf(m,"%d",i); 
				strcpy(a[4],m);
				strcat(a[4],a[1]);
				break;
			}
			
		}
		
		
		key2.data=a[3];
		key2.size=strlen(a[3])+1;
		data2.data=a[4];
		data2.size=strlen(a[4])+1;
		
		ret1 = g_guizenew2db->db->put(g_guizenew2db->db, NULL,
                           &key2, &data2,
                           g_guizenew2db->put_flags);
		
                if ( ret1 == DB_KEYEXIST ) {
                  #ifdef DEBUG
                     // printf("ffbd\n");
                      fprintf( stderr,
                          "name index: key %*s for pnode %llu already recorded\n",
                           length, val->pdb_data, key->pnum );
                                #endif /* DEBUG */
               } else {
                         wdb_check_err(ret1);
                      } 

		redisContext* conn = redisConnect((char *)"127.0.0.1",6379);  
                if(conn->err)   printf("connection error:%s\n",conn->errstr);  
   		redisReply* reply = redisCommand(conn,"select 0");  
    		freeReplyObject(reply);
    		reply = redisCommand(conn,"sadd %s %s",a[3],a[4]); 
		count++;
    		//redisCommand(conn,"sadd 1.0 %s",argv[2]); 
    		freeReplyObject(reply); 
		redisFree(conn);  
	
        }
        if ( DB_NOTFOUND != ret ) 
	{
      		wdb_check_err(ret);
        }					
	printf("count:%d\n",count);                                          
}


void guize(void)
{
   DBC                  *childc = NULL;
   DBT                   dbt_child;
   DBT                   dbt_parent;
   provdb_key            child;
   provdb_key            parent;
   int                   ret,ret1;
   char *  pname;
   char *  cname;
   int count=0;

   memset(&dbt_child, 0, sizeof(dbt_child));
   memset(&dbt_parent , 0, sizeof(dbt_parent));
   newname();
   //
   // Process the entries
   //

   // Open a cursor
   ret = g_childdb->db->cursor(g_childdb->db, NULL, &childc, 0);
   wdb_check_err(ret);

   // Iterate over the main database
   while ( 0 == (ret = childc->c_get(childc, &dbt_parent, &dbt_child, DB_NEXT)) ) {
      assert( sizeof(child) == dbt_child.size );
      assert( sizeof(parent)  == dbt_parent.size );
      
      memcpy(&child , dbt_child.data , dbt_child.size );
      memcpy(&parent, dbt_parent.data, dbt_parent.size);

      pname = get_newname(parent.pnum,"NAME");
     if(!pname)
        {
            pname = get_string(parent.pnum,"TYPE");
        if(!pname) continue;
     }
     cname = get_newname(child.pnum, "NAME");
     if(!cname)
        {
            cname = get_string(child.pnum,"TYPE");
        if(!cname) 
        {free(pname),pname=NULL;
         continue;}
     }

   DBT                        dbt_guize_key;
   DBT                        dbt_guize_val;

   memset(&dbt_guize_key, 0, sizeof(dbt_guize_key));
   memset(&dbt_guize_val, 0, sizeof(dbt_guize_val));

   dbt_guize_key.data = pname;
   dbt_guize_key.size = strlen(pname)+1;

   dbt_guize_val.data = cname;
   dbt_guize_val.size = strlen(cname)+1;
   count++;
   ret1 = g_guizedb->db->put(g_guizedb->db, NULL,
                           &dbt_guize_key, &dbt_guize_val,
                           g_guizedb->put_flags);

   if ( ret1 == DB_KEYEXIST ) {
#ifdef DEBUG
       fprintf( stderr,
            "name index: key %*s for pnode %llu already recorded\n",
                length, val->pdb_data, key->pnum );
#endif /* DEBUG */
   } else {
       wdb_check_err(ret1);
   }

     free(cname),cname=NULL;
     free(pname),pname=NULL;

   }

   if ( DB_NOTFOUND != ret ) {
      wdb_check_err(ret);
   }
   printf("count-g:%d\n",count);
}


void prune_guize(void)
{
   DBC                  *namec = NULL;
   DBT                   dbt_name;
   DBT                   dbt_pnode;
   DBT                  dbt_new1;
   DBT                  dbt_new2;
   char                 *name;
   char                  *pnum;
   int                   ret;
   int ret1;
   int                    num;
   char * new1=NULL;
   char * new2=NULL;
   char* new11=NULL;
   char* new22=NULL;

  
   memset(&dbt_name , 0, sizeof(dbt_name));
   memset(&dbt_pnode, 0, sizeof(dbt_pnode));

   //
   // Process the entries
   //

   // Open a cursor
   ret = g_guizedb->db->cursor(g_guizedb->db, NULL, &namec, 0);
   wdb_check_err(ret);
   num=0;

   // Iterate over the main database
   while ( 0 == (ret = namec->c_get(namec, &dbt_name, &dbt_pnode, DB_NEXT)) ) {

      name = malloc(dbt_name.size + 1);
      memcpy(name, dbt_name.data, dbt_name.size);
      name[dbt_name.size] = '\0';
      
      pnum = malloc(dbt_pnode.size + 1);
      memcpy(pnum, dbt_pnode.data, dbt_pnode.size);
      pnum[dbt_pnode.size] = '\0';
  //    printf( "%s -> %s\n", name, pnum );
     if(strstr(name,"mount")||strstr(name,"PIPE")||strstr(name,"tmp")||strstr(name,"/pulse-shm")||strstr(name,"lasagna")||strstr(name,".cache")||strstr(name,"./configure")||strstr(name,"./Configure")||strstr(pnum,"mount")||strstr(pnum,"PIPE")||strstr(pnum,"tmp")||strstr(pnum,"/pulse-shm")||strstr(pnum,"lasagna")||strstr(pnum,".cache")||strstr(pnum,"./configure")||strstr(pnum,"./Configure")||strstr(pnum,"Cache")||strstr(pnum,"cache")||strstr(pnum,"CACHE")||strstr(pnum,"pass")||strstr(pnum,"default")||strstr(name,"Cache")||strstr(name,"cache")||strstr(name,"CACHE")||strstr(name,"pass")||strstr(name,"default")||strstr(name,"./")||strstr(pnum,"./")||strstr(name,"conf.")||strstr(pnum,"conf.")||strstr(name,".swp")||strstr(pnum,".swp")||strstr(pnum,".so")||strstr(name,".so")||strstr(pnum,".sh")||strstr(name,".sh"))
     {
        ;
       // namec->c_del(namec,NULL);
        //getchar();
     }
     else if((name[0]=='/')&&(name[1]>='0'&&name[1]<='9')&&(name[2]>='0'&&name[2]<='9')&&(name[3]=='/'))
      ;
     else if((name[0]=='/')&&(name[1]>='0'&&name[1]<='9')&&(name[2]>='0'&&name[2]<='9')&&(name[3]>='0'&&name[3]<='9')&&(name[4]=='/'))
      ;
     else if((name[0]=='/')&&(name[1]>='0'&&name[1]<='9')&&(name[2]>='0'&&name[2]<='9')&&(name[3]>='0'&&name[3]<='9')&&(name[4]>='0'&&name[4]<='9')&&(name[5]=='/'))
      ;
     else if((name[0]=='/')&&(name[1]>='0'&&name[1]<='9')&&(name[2]>='0'&&name[2]<='9')&&(name[3]>='0'&&name[3]<='9')&&(name[4]>='0'&&name[4]<='9')&&(name[5]>='0'&&name[5]<='9')&&(name[6]=='/'))
     ;
     else if((pnum[0]=='/')&&(pnum[1]>='0'&&pnum[1]<='9')&&(pnum[2]>='0'&&pnum[2]<='9')&&(pnum[3]=='/'))
      ;
     else if((pnum[0]=='/')&&(pnum[1]>='0'&&pnum[1]<='9')&&(pnum[2]>='0'&&pnum[2]<='9')&&(pnum[3]>='0'&&pnum[3]<='9')&&(pnum[4]=='/'))
      ;
     else if((pnum[0]=='/')&&(pnum[1]>='0'&&pnum[1]<='9')&&(pnum[2]>='0'&&pnum[2]<='9')&&(pnum[3]>='0'&&pnum[3]<='9')&&(pnum[4]>='0'&&pnum[4]<='9')&&(pnum[5]=='/'))
      ;
     else if((pnum[0]=='/')&&(pnum[1]>='0'&&pnum[1]<='9')&&(pnum[2]>='0'&&pnum[2]<='9')&&(pnum[3]>='0'&&pnum[3]<='9')&&(pnum[4]>='0'&&pnum[4]<='9')&&(pnum[5]>='0'&&pnum[5]<='9')&&(pnum[6]=='/'))
     ;
      else
       {
         new1=NULL;
         new2=NULL;
         new11=NULL;
         new22=NULL;
         new1=strstr(name,"/home/apps");
         new2=strstr(pnum,"/home/apps");
      if((new1!=NULL)&&(new2==NULL))
       {
       // printf("name is %s.\n",name);
        new11=comp1(name);
       //   printf("new11 is %s.\n",new11);
        new1=version(new11);
       //   printf("new1 is %s.\n",new1);
       memset(&(dbt_new1), 0, sizeof(dbt_new1));
       (dbt_new1).data = new1;
       (dbt_new1).size = strlen(new1)+1;
        //  printf("new1 is %s.\n",new1);
        //  getchar();
       ret1 = g_guizenewdb->db->put(g_guizenewdb->db, NULL,
                           &dbt_new1, &dbt_pnode,
                           g_guizenewdb->put_flags);
 
       free(new1);
       free(new11);
       }
      
      if((new1==NULL)&&(new2!=NULL))
       {
        new22=comp1(pnum);
        new2=version(new22);
       memset(&dbt_new2, 0, sizeof(dbt_new2));
       dbt_new2.data = new2;
       dbt_new2.size = strlen(new2)+1;
       ret1 = g_guizenewdb->db->put(g_guizenewdb->db, NULL,
                           &dbt_name, &dbt_new2,
                           g_guizenewdb->put_flags);
        free(new2);
        free(new22);
       }

       if((new1!=NULL)&&(new2!=NULL))
       {
        new11=comp1(name);
        new22=comp1(pnum);
       new1=version(new11);
       new2=version(new22);
       memset(&dbt_new1, 0, sizeof(dbt_new1));
       memset(&dbt_new2, 0, sizeof(dbt_new2));
       dbt_new1.data = new1;
       dbt_new1.size = strlen(new1)+1;
       dbt_new2.data = new2;
       dbt_new2.size = strlen(new2)+1;
       ret1 = g_guizenewdb->db->put(g_guizenewdb->db, NULL,
                           &dbt_new1, &dbt_new2,
                           g_guizenewdb->put_flags);
       free(new1);free(new11);
       free(new2);free(new22);
       }

       if((new1==NULL)&&(new2==NULL))
       {
  ret1 = g_guizenewdb->db->put(g_guizenewdb->db, NULL,
                           &dbt_name, &dbt_pnode,
                           g_guizenewdb->put_flags);
       }
    }
      num++;

      free(name), name = NULL;
      free(pnum), pnum = NULL;

  }

 //  printf("num:%d\n",num);
   if ( DB_NOTFOUND != ret ) {
      wdb_check_err(ret);
   }
}

char* version(char *name)
{

 char* new;
char* tian;
int flag;
char * new1=NULL;

new=malloc(sizeof(char)*100);
memcpy(new,"/home/apps/4/apache_1.3.0",26);
  new1=strstr(name,"1.3");
      if(new1!=NULL)
       {
         if(new1[4]>='0'&&new1[4]<='9')
          flag=0;
         if(new1[5]>='0'&&new1[5]<='9')
          flag=1;
         if(flag==0)
      strcat(new,&new1[5]);
         else
      strcat(new,&new1[6]);
       // printf("new is %s\n",new);
       return new;
          }
memcpy(new,name,strlen(name)+1);
return new;
}

char* comp1(char *original)
{

char med[100];
//char good[100]="/home/apps";
char* tian;
int m,i,j;
char* good;

good=malloc(sizeof(char)*100);
memcpy(good,"/home/apps",11);
   m=strlen(original);
//printf("m is %d\n",m);
   for(i=10,j=0;i<m+1;i++,j++)
      med[j]=original[i];

//printf("med is %s\n",med);
tian=strcat(good,med);
//printf("original is %s\n",tian);
return tian;
}

char* comp(char *original)
{

char med[100];
//char good[100]="/home/apps";
char* tian;
int m,i,j;
char* good;

good=malloc(sizeof(char)*100);
memcpy(good,"/home/apps",11);
   m=strlen(original);
//printf("m is %d\n",m);
   for(i=17,j=0;i<m+1;i++,j++)
      med[j]=original[i];

//printf("med is %s\n",med);
tian=strcat(good,med);
//printf("original is %s\n",tian);
return tian;
}

static char * get_newname(pnode_t pnum, const char * attr)
{
   DBC                       *pdbc = NULL;
   DBT                        dbt_key;
   DBT                        dbt_val;
   provdb_key                 key;
   provdb_val                *val;
   const char                *attrname;
   char                      *data, *attrval = NULL;
   size_t                     datalen;
   int                        serrno;
   int                        ret;
   

  
   memset(&dbt_key, 0, sizeof(dbt_key));
   memset(&dbt_val, 0, sizeof(dbt_val));


   ret = g_newnamedb->db->cursor(g_newnamedb->db, NULL, &pdbc, 0);
   wdb_check_err(ret);

   
   dbt_key.data = &pnum;
   dbt_key.size = sizeof(pnode_t);


   ret =  pdbc->c_get(pdbc, &dbt_key, &dbt_val, DB_SET);

  
    if(ret==0){
      attrval=malloc(dbt_val.size+1);
      memcpy(attrval,dbt_val.data,dbt_val.size);
      attrval[dbt_val.size]=0;
   }
   //printf("name=%s\n",attrval);
   return attrval;
}

static char * get_string(pnode_t pnum, const char * attr)
{
   DBC                       *pdbc = NULL;
   DBT                        dbt_key;
   DBT                        dbt_val;
   provdb_key                 key;
   provdb_val                *val;
   const char                *attrname;
   char                      *data, *attrval = NULL;
   size_t                     datalen;
   int                        serrno;
   int                        ret;
   struct waldo_db * tmp=g_provdb;
   memset(&dbt_key, 0, sizeof(dbt_key));
   memset(&dbt_val, 0, sizeof(dbt_val));

  // if(j) tmp=g_provdb;
   ret = tmp->db->cursor(tmp->db, NULL, &pdbc, 0);
   wdb_check_err(ret);

   key.pnum = pnum;
   key.version = 0;
   dbt_key.data = &key;
   dbt_key.size = sizeof(key);

   ret =  pdbc->c_get(pdbc, &dbt_key, &dbt_val, DB_SET);
   
   while ( ret != DB_NOTFOUND ) {
    val = malloc(dbt_val.size);
    if ( val == NULL ) {
    serrno = errno;
    fprintf( stderr, "Malloc of provdb record failed %s\n",
         strerror(serrno) );
    errno = serrno;
    return 0;
    }
    memcpy(val, dbt_val.data,dbt_val.size);
    attrname = PROVDB_VAL_ATTR(val);
    data = PROVDB_VAL_VALUE(val);
       datalen = PROVDB_VAL_VALUELEN(val);
    if( strncmp(attr, attrname, 4) ==0 ) {
        attrval = (char *)malloc(datalen+1);
        memcpy(attrval, data, datalen);
        attrval[datalen] = '\0';
        free(val),val = NULL;
        break;
    }
    else ret = pdbc->c_get(pdbc, &dbt_key, &dbt_val, DB_NEXT_DUP);
    free(val),val = NULL;
   }
   //if(pnum==3)
      //printf("attrval=%s\n",attrval);
   return attrval;
}





void jiequ(char *str1,char str2[100],char str3[100])
{
	int n,m,i;
	strcpy(str2,str1);
	n=m=strlen(str2);
	while(n>0&&str2[n]!='/') n--;
		str2[n]=NULL;
        
	for( i=0;i<m-n;i++)
                str3[i]=str1[n+i]; 
        if(n==0) {strcpy(str2,str1);i=0;} 
	str3[i]=NULL; 
}  

int f_pnum(char *childReply){
	int pnum=0;
	int i=0;
	while(childReply[i]!='.'){
		pnum=pnum*10+childReply[i]-'0';
		i++;
	}
	return pnum;
}






