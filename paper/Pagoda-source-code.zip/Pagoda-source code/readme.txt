#xxxxxx Pagoda: A hybrid Approach to Enable Efficient and Real-time Provenance Based Intrusion Detection in Big Data Environments

#### How to run it: 

Open redis service by running the following command:

Note the redis file location, run:

`/usr/local/sbin/vsftpd &`

#####There are four steps to generate a rule database.

At `graduate` directory, run:

1.`./flushall `

2.`/jiance-redis/jiance <filename> -d 'g'`

3.`/jiance-redis/jiance <filename> -d 'p'`

4.`/jiance-redis/jiance <filename> -d 'b'`

The data will be imported into the redis database.

#####There are three steps to perform the detection step.

At `graduate` directory, run:

1.`./flushdb  `

2.`./redis <filename1> <filename2>`

3.`/jiance-redis/jiance <filename> -d 'j'`


