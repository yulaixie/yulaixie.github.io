#include<stdio.h>
#include <math.h>
/*double ceil(double)����ȡ������*/
/*double floor(double)����ȡ������*/

int ToBinary(long x, long s, long *a)
{
long i=1; long j=0;
/**printf("x=%ld\n",x);
printf("s=%ld\n",s);
getch(); */
while((x/2>=2)&&(i<=s))
{
  a[s-i]=x%2;
/**  printf("%ld\n",a[s-i]);
  getch();   */
  x=x/2;
  i++;
}
if(i<=s)
{
a[s-i]=x%2;
/*printf("%ld\n",a[s-i]);  */
i++;
}
if(i<=s)
{
a[s-i]=x/2;
/*printf("%ld\n",a[s-i]);  */
}
for(i++;s-i>=0;i++)
  {
    a[s-i]=0;
/*    printf("%ld\n",a[s-i]);    */
  }
/*  getch();  */

return 0;
}

long* Bianma(long x)
{
long i=1; long h=0; long z=0;  long s=0;  long j=0;  long k=0; long p[100];
long aa=0; long ab=1;    long m=0;  long n;     long t=0;  long q[100]; long x1=0;
long qq[1];

if (x==0)
{
	qq[0]=0;
	qq[1]=0;
return qq;
}
x1=x;
if(x==8||x==64||x==512||x==4096||x==32768||x==262144||x==2097152)
   x1=x+1;
/*1. compute h*/
h=(log(x1))/(log(8));

/*2. compute z*/
z=7*pow(8,h);

/*3. compute s*/
s=ceil(log(z)/log(2));

if((x-pow(8,h))<(pow(2,s)-z))
{
for (i=0;i<s-1;i++)
p[i]=0;
ToBinary(x-pow(8,h),s-1,p);

/*1. write h+1 in unary*/
for (m=0;m<h+1;m++)
{
if(m<h)
q[m]=0;
else
q[m]=1;
}
 /*2. write binary*/
for(j=0,m=h+1;j<s-1;j++,m++)
{
q[m]=p[j];
}

 /*bianma:q[j],length:s+h*/
//for(j=0;j<s+h;j++)
//{
//printf("%ld",q[j]);
//}
//printf("\n");
return q;

}

else
{

for (i=0;i<s;i++)
p[i]=0;
ToBinary(x-pow(8,h)-z+pow(2,s),s,p);

/*1. write h+1 in unary*/
for (m=0;m<h+1;m++)
{
if(m<h)
q[m]=0;
else
q[m]=1;
}

 /*2. write binary*/
for(j=0,m=h+1;j<s;j++,m++)
{
q[m]=p[j];
}

 /*bianma:q[j],length:s+h+1*/
//for(j=0;j<s+h+1;j++)
//{
//printf("%ld",q[j]);
//}
//printf("\n");
return q;

}

}


/**int main()
{
long t; long x;
printf("please scanf the integer that you want to encode:");
scanf("%ld",&x);
t=BianMa(x);
printf("\n");
printf("The length of bianma %ld is %ld", x, t);
/**BianMa(2);
BianMa(3);
BianMa(4);
BianMa(5);
BianMa(6);
BianMa(7);
BianMa(8);
BianMa(9);
BianMa(10);
BianMa(11);
BianMa(12);
BianMa(13);
BianMa(14);
BianMa(15);
BianMa(16); */
/*BianMa(2);*/
/**getch();

return 0;
}*/
