char* webcompression(long ,long, Node**, long);
