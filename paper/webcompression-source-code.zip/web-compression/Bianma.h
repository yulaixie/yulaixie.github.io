long* Bianma(long x);
