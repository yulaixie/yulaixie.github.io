
typedef struct Node{
	long	 NodeNo;			
	char Inode[256];
	char Pid[256];
	char Name[512];
	char Type[256];
	char Argv[1024];
	char Env[4096];
	char FreezeTime[256];
	long   successors[2000];
	long   outdegree;    
	long ChainLength;
} Node;



