#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "Bianma.h"
#include "Node.h"


long Copylist(long NUM,long W, int* copylist, long* Extra, Node**m_ptrnode, long R)
 {
   /*NUM is the sequence number of the current node*/
   /*MAX: the number of similarity*/
   /**1.look for the reference list in the preceding W nodes
       compare the successors of preceding w nodes with the current nodes
       Currently, the closer node with the same number of same successors
       will win */
       /*flag[i] identifies the number of same successors*/
     long i,i1,i2,i3; long j,j1=0,j2,j3; long k; long flag[1000];   long MAX=0;   long r=0;
     long h1,h2,h3=0,h4;
     long NoExtra[2000];  int flag1;
/**     Node p[3]={2,1,4,1,5,1};   /*����������н�����ԣ������������*/
/**       printf("%ld\n",p[2].successors[0]);
      printf("%ld\n",p[1].successors[0]);*/

//    getch();
    if (NUM<=W)
		W=NUM-1;
    for(h4=0;h4<W;h4++)
     flag[h4]=0;
	//sometimes, some nodes miss as a result of WAP
    for(i=W;i>0;i--)
	{
		if(m_ptrnode[NUM-i]==NULL)
		{
    m_ptrnode[NUM-i] = (Node*)malloc(sizeof(Node));
    m_ptrnode[NUM-i]->outdegree=0;
		}
	}
//     printf("good1\n");
//    printf("w=%ld,NUM=%ld\n",W,NUM);
  //  printf("flag[0]=%ld,flag[1]=%ld\n",flag[0],flag[1]);
 /*   printf("%ld,%ld\n",p[0].successors[0],p[2].successors[0]);*/
//    getch();

       for(i=W;i>0;i--)
       for(j=0;j<m_ptrnode[NUM-i]->outdegree;j++)
       for(k=0;k<m_ptrnode[NUM]->outdegree;k++)
       /* whether p[NUM-i]->successors[j] is also in the current list*/
         if ((m_ptrnode[NUM-i]->successors[j])==(m_ptrnode[NUM]->successors[k]))
           {
//             printf("i=%ld,j=%ld,k=%ld,%ld,%ld\n",i,j,k,m_ptrnode[NUM-i]->successors[j],m_ptrnode[NUM]->successors[k]);
             flag[i-1]=flag[i-1]+1;
             }
//    printf("good3!");
//    getch();
//    printf("%ld%ld\n",flag[0],flag[1]);
     /*find the biggest flag[i-1] in flag shuzu, and the corresponding node is
      reference list, the number is NUM-r*/
/**        for(k=0;k<W;k++)
        {
         if (flag[k]>MAX)
            {
            r=k+1;
            MAX=flag[k];
            }
         }
*/
		 k=0;
		 while(k<W)
		 {
			 if((flag[k]>MAX)&&(m_ptrnode[NUM-(k+1)]->ChainLength<R))
			 {
            r=k+1;
            MAX=flag[k];
			m_ptrnode[NUM]->ChainLength=m_ptrnode[NUM-(k+1)]->ChainLength+1;
            }
			 else
				 k++;
		 }
//    printf("MAX is %ld\n", MAX);
//    printf("r is %ld\n",r);
//    printf("good4!");
    if(MAX==0)
    {
 //     copylist[0]=0;
    for(j=0;j<(m_ptrnode[NUM]->outdegree);j++)
      {
       Extra[j]=m_ptrnode[NUM]->successors[j];
//      printf("%ld",Extra[j]);
      }
    }
    else
 {
   /*2.compute the copy list of current node
   for every number in reference list, if it still exists in current list(i.e.,p[NUM]->successors),
   then the corresponding position of copy list is 1, otherwise, is 0.*/
   /*initiate copylist*/
   for(i1=0;i1<m_ptrnode[NUM-r]->outdegree;i1++)
   {
    copylist[i1]=0;
   }
   for(j2=0;j2<MAX;j2++)
   {
    NoExtra[j2]=0;
   }
   for(j3=0;j3<(m_ptrnode[NUM]->outdegree)-MAX;j3++)
   {
    Extra[j3]=0;
   }
    for(h1=0;h1<m_ptrnode[NUM-r]->outdegree;h1++)
    for(h2=0;h2<m_ptrnode[NUM]->outdegree;h2++)
         if ((m_ptrnode[NUM-r]->successors[h1])==(m_ptrnode[NUM]->successors[h2]))
               {
                  copylist[h1]=1;
 //                 printf("%ld,%ld\n",m_ptrnode[NUM-r]->successors[h1],m_ptrnode[NUM]->successors[h2]);
 //                 printf("very good!\n");
                   NoExtra[h3]=h2;
                   h3++;
                   }

     for(h2=0;h2<m_ptrnode[NUM]->outdegree;h2++)
    {     /*if h2 not in NoExtra, put p[NUM]->successors[h2] in Extra.*/
         for(i2=0;i2<MAX;i2++)
          if (h2==NoExtra[i2]) flag1=1;
          if (flag1==0)
          {
          Extra[j1]= m_ptrnode[NUM]->successors[h2];
          j1++;
          }
          flag1=0;
     }

 //    printf("good5");
 //    getch();
  /*printf the copylist and extra nodes number*/
//  for(i=0;i<m_ptrnode[NUM-r]->outdegree;i++)
 //     printf("%d",copylist[i]);
 //     printf("\n");
  //    getch();
//  for(j=0;j<((m_ptrnode[NUM]->outdegree)-MAX);j++)
//      printf("%ld",Extra[j]);
//       printf("good6");
 //     getch();
 }

//	if ((m_ptrnode[NUM]->outdegree)-MAX<0)
//	           return 0;
// return (m_ptrnode[NUM]->outdegree)-MAX;
	return r;

 }/*copylist*/

int Interval(long Extra_n, long* Extra, long* LeftExtreme, long* Length, long* Residuals)
{
  long inter[2000]; int r; int j=0;
  int m1=0; int m2=0; int k1=0;  int flag=0; int i;  int k;  int h; long left;int j1,j2,j3;
  /*test*/
//  for(i=0;i<Extra_n;i++)
//  printf("%ld",Extra[i]);
//  printf("\n");
//  getch();

  if (Extra_n==1)
  {
  Residuals[0]=Extra[0];
  LeftExtreme[0]=0;
  Length[0]=0;
  j=1;
  }
  else
  {
  /*1. find the residuals*/
  if (Extra[1]-Extra[0]!=1)
     {
     Residuals[j++]=Extra[0];
 //    printf("%ld\n",Residuals[j-1]);
 //    getch();
     }
  for(i=1;i<(Extra_n-1);i++)
  {
   if (((Extra[i]-Extra[i-1]!=1)!=0)&&((Extra[i+1]-Extra[i]!=1)!=0))
      {
      Residuals[j]=Extra[i];
      j++;
  //    printf("%ld\n",Residuals[j-1]);
 //    getch();
      }
  }
  if (Extra[i]-Extra[i-1]!=1)
      Residuals[j++]=Extra[i];
      /*test*/
//      for(j1=0;j1<j;j1++)
//   printf("%ld\n",Residuals[j1]);
//   printf("good1!");       
//   printf("\n");
 //  getch();
  /*2. find the inter,if Extra[i] not in Residuals, put it in inter[];*/
  for(i=0;i<Extra_n;i++)
  {
  for(k=0;k<j;k++)
   {
   if (Extra[i]==Residuals[k])    
   {
//   printf("%ld",Residuals[k]);
//   printf("good1!");
//   printf("\n");
//   getch();
     flag=1;
     }
   }
   if (flag==1)
      flag=0;
   else
       {
       inter[k1++]=Extra[i];
//        printf("%ld",inter[k1-1]);
//   printf("\n");
 //  getch();
   }
  }
    /*test*/
    if (k1==0)
        {
        inter[0]=0;
//        printf("%ld",inter[0]);
//   printf("\n");
//   getch();
        }
    else
    {
//      for(j1=0;j1<k1;j1++)
//   printf("%ld",inter[j1]);
//   printf("\n");
 //  getch();
  /*3. analyze the inter, to find the data value of LeftExtreme and Length*/
  for(h=0,r=1,left=inter[0];h<Extra_n-j-1;h++)
     if(inter[h+1]-inter[h]==1)
        r++;
     else
     {
       LeftExtreme[m1++]=left;
       Length[m2++]=r;
       left=inter[h+1];
       r=1;
       }
   LeftExtreme[m1++]=left;
       Length[m2++]=r;
   }
   /*4. printf the LeftExtreme, Length and Residuals*/
   if (j==0)
   {
   Residuals[0]=0;
//   printf("%ld",Residuals[0]);
 //  getch();
   }
//   else
//   for(j1=0;j1<j;j1++)
//   printf("%ld",Residuals[j1]);
//   printf("\n");
//   getch();
   if (m1==0)
   {
   LeftExtreme[0]=0;
   Length[0]=0;
//   printf("%ld",LeftExtreme[0]);
//   printf("%ld",Length[0]);
//   getch();
   }
//   else
//   {
//   for(j2=0;j2<m1;j2++)
//   printf("%ld",LeftExtreme[j2]);
//   printf("\n");
//   for(j3=0;j3<m2;j3++)
//   printf("%ld",Length[j3]);
//   getch();
//   }
  }
   return j;
}

int gap(long x,long n, long* Residuals)
{
  int i,j,k;   long Gap[2000];
  for(i=0;i<n;i++)
  Gap[i]=0;

//  if (n==1) Gap[0]=Residuals[0];
//  else
//  {
  Gap[0]=Residuals[0]-x;
  for(j=0;j<n-1;j++)
  Gap[j+1]=Residuals[j+1]-Residuals[j];
//  }
  for(k=0;k<n;k++)
  {
  Residuals[k]=Gap[k];
//  printf("%ld,",Gap[k]);
  }
//  getch();
  return 0;
}

char* webcompression(long x,long W,Node**ptrnode, long R)
{
 /*Node *p[30000];   */
 int copylist[2000]; int t=0;
 long Extra[2000];
 long LeftExtreme[2000];
 long Length[2000];
 long i,j,k=0;
 long* sum0=NULL; long* sum_interval=NULL; long* sum1=NULL; long* sum2=NULL; long* sum3=NULL; long* sum4=NULL;//sum_total=0;
 char pp[40]; char pp1[40]; char pp11[40]; char pp22[40]; char pp2[40]; char pp3[40]; char aa[2000]="";
 char pp0[1]; char pp4[40];
  long sum=0; long r=0; int kk=0;
 /*x identifies the value of this node*/
 long n;/*n identifies the number of residuals*/
 long m;/*m identifies the number of Extra*/
 long Residuals[2000];

// printf("good_web!\n");
 for(i=0;i<2000;i++)
   copylist[i]=2;
    for(i=0;i<2000;i++)
      Extra[i]=0;
      for(i=0;i<2000;i++)
      LeftExtreme[i]=0;
      for(i=0;i<2000;i++)
      Length[i]=0;
       for(i=0;i<2000;i++)
   Residuals[i]=0;
 /*Extra[0]=1; Extra[1]=4;Extra[2]=5;Extra[3]=7;Extra[4]=9;Extra[5]=10; Extra[6]=12; */
 /*Residuals[1]=3;Residuals[2]=5;Residuals[3]=8;Residuals[4]=10;*/
 /*1.read file to preserve information to the structure shuzu*/
 /**2.Three steps of web compression algorithms
    2.1 using copy list technology
    2.2 using interval technology
    2.3 using gap technology */

    r=Copylist(x,W,copylist,Extra,ptrnode,R);
	sum0=Bianma(r);
//	printf("r=%ld\n",r);
//	printf("%ld,%ld,%ld\n",sum0[0],sum0[1],sum0[2]);
//	printf("\n0:the bianma is %s\n",aa);
	while(sum0[k]==0||sum0[k]==1)
	{
//		printf("the k is %ld, sum0[k] is %ld\n",k,sum0[k]);
		ltoa(sum0[k],pp0,10);
		strcat(aa,pp0);
		k++;
//		pp0=NULL;
	}
	if(x<4)
	printf("\nsum0:the bianma is %s\n",aa);
 //   printf("m=%ld\n",m);
    /*1.printf the copylist*/
 //   printf("copylist:");
	
	  i=0;
//	  printf("copylist is %d%d%d\n",copylist[0],copylist[1],copylist[2]);
	  while(copylist[i]!=2)
		  i++;
 //    for(j=0;j<i;j++)    /*4����copylist��λ����Ҳ��reference list��λ����Ӧ����ǰһ�����÷��ػ�����*/
 //    printf("%d",copylist[j]);
     sum1=Bianma(i);
	 k=0;
	 while(sum1[k]==0||sum1[k]==1)
	{
		ltoa(sum1[k],pp1,10);
		if(x<4)
		printf("pp1 is %s\n",pp1);
		strcat(aa,pp1);
		k++;
//		pp1=NULL;
	}
	 if(x<4)
printf("\nsum1:the bianma is %s\n",aa);
	 i=0;
	  while(copylist[i]!=2)
	  {
		  ltoa(copylist[i],pp11,10);
		  strcat(aa,pp11);
		  i++;
//		  pp11=NULL;
	  }
//     printf("sum1:%ld\n",sum1);
 //     printf("\n");
 //    getch();
	  if(x<4)
	  printf("\nsum-copylist:the bianma is %s\n",aa);
	 j=0;
	while (Extra[j]!=0)
		j++;
	m=j;
     if(m==0)
     {
//     LeftExtreme[0]=0;
//     sum_interval=0;
 //    sum2=0;
//     Length[0]=0;
   //  sum3=0;
//     Residuals[0]=0;
  //   sum4=0;
 //    printf("LeftExtreme:%ld,Length:%ld,Residuals:%ld",LeftExtreme[0],Length[0],Residuals[0]);
 //    getch();
     }
     else
     {
    n=Interval(m,Extra,LeftExtreme,Length,Residuals);
//    printf("n=%ld\n",n);
    /*2.printf the LeftExtreme and Length*/
 //    printf("LeftExtreme and Length:");
	    if(Length[0]==0)
		{
//			sum_interval=1; //interval==0
			ltoa(0,pp22,10); /*use two 0 to represent the case when the number of intervals is 0 (the residual still exists)*/
		  strcat(aa,pp22);
		  strcat(aa,pp22);
//			sum2=0;
//			sum3=0;
		}
		else
		{
         for(i=0;i<2000;i++)
          {
          sum+=Length[i];
          if(m-n-sum==0)
          break;
          
		 }
		 sum_interval=Bianma(i+1);
     k=0;
		 while(sum_interval[k]==0||sum_interval[k]==1)
	{
		ltoa(sum_interval[k],pp22,10);
		strcat(aa,pp22);
		k++;
//		pp22=NULL;
	}
		 if(x<4)
	  printf("\nsum-interval:the bianma is %s\n",aa);
          for(j=0;j<i+1;j++)
          {
//          printf("%ld,",LeftExtreme[j]);
           sum2=Bianma(LeftExtreme[j]);
		   k=0;
		 while(sum2[k]==0||sum2[k]==1)
		 {
		ltoa(sum2[k],pp2,10);
		strcat(aa,pp2);
		k++;
//		pp2=NULL;
		 }
		 sum2=NULL; 
           }
		  if(x<4)
	  printf("\nsum-left:the bianma is %s\n",aa);
//           printf("sum2:%ld\n",sum2);
 //         printf("\n");
          for(j=0;j<i+1;j++)
          {
//          printf("%ld,",Length[j]);
          sum3=Bianma(Length[j]);
		  k=0;
		 while(sum3[k]==0||sum3[k]==1)
		 {
		ltoa(sum3[k],pp3,10);
		strcat(aa,pp3);
		k++;
//		pp3=NULL;
		 }
		 sum3=NULL; 
          }
		  if(x<4)
	  printf("\nsum-length:the bianma is %s\n",aa);
		}
//          printf("sum3:%ld",sum3);
    /*3.printf the Residuals*/
//    printf("Residuals:");
    if (n==0)
    sum4=0;
	else if (n==1)
    {
		strcat(aa,"1");
		sum4=Bianma(Residuals[0]);
		k=0;
		 while(sum4[k]==0||sum4[k]==1)
		 {
		ltoa(sum4[k],pp4,10);
		strcat(aa,pp4);
		k++;
//		pp4=NULL;
		 }
		 if(x<4)
	  printf("\nsum4:the bianma is %s\n",aa);
	}
    else
	{
    t=gap(ptrnode[x]->NodeNo,n,Residuals);
	if (Residuals[0]<=0)
	{
    Residuals[0]=-Residuals[0];
	strcat(aa,"0");
	}
	else
     strcat(aa,"1");
//    printf("%ld,",Residuals[i]);
    sum4=Bianma(Residuals[0]);
           k=0;
		 while(sum4[k]==0||sum4[k]==1)
		 {
		ltoa(sum4[k],pp4,10);
		strcat(aa,pp4);
		k++;
//		pp4=NULL;
		 }
		 sum4=NULL;
    for(i=1;i<n;i++)
    {
    if (Residuals[i]<=0)
    Residuals[i]=-Residuals[i];
//    printf("%ld,",Residuals[i]);
    sum4=Bianma(Residuals[i]);
           k=0;
		 while(sum4[k]==0||sum4[k]==1)
		 {
		ltoa(sum4[k],pp4,10);
		strcat(aa,pp4);
		k++;
//		pp4=NULL;
		 }
		 sum4=NULL; 
    }
	if(x<4)
	  printf("\nsum4:the bianma is %s\n",aa);
 //   sum4+=1;/*��һλ������ʾ��һ��Residuals�������Ǹ�*/
	}
//    printf("sum4:%ld",sum4);
//    printf("\n");
 //    getch();
     }

     /*compute the length of bianma*/
 //    sum_total=sum0+sum1+sum_interval+sum2+sum3+sum4;
//     printf("The length of Bianma is %ld.",sum1+sum2+sum3+sum4);
 //    getch();
 if(x==16)
    printf("\n for the %ld line, the bianma is %s\n",x,aa);
    return aa;
}


