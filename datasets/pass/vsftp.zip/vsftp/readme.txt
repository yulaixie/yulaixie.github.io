vsftpd-test-normal  is  the vsftpd-1-normal
   vsftpd-2-intrusion-normal, 1-50 is normal(intrusion?right), 51-102 is intrusion(normal? right)

