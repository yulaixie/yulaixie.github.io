distccd-test-normal is the same as the distccd-1
     


distccd-2, 1-50 is an intrusion set, 52-101 is a normal  set, which is used to detect the false alarm rate


distccd-intrusion-trace is an instrusion set, which is used to detect the detection rate.
