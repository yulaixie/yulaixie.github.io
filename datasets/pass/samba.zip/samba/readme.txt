samba-test-normal is the samba-1-provenance
  to used as rule database, samba-2-normal-provenance is used to test the false alarm rate��samba-2-intrusion-provenance is used to test the detection rate. 

